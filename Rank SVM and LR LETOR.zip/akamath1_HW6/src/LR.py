from sklearn.cross_validation import KFold
import numpy as np


def train(X,Y,w):
    max_epochs=3000
    epochs=0
    while(epochs<max_epochs):

            lamda=0.0001
            step=0.00001

#                       
            X_train = X
                
            Y_train = Y
                
            grad=gradient(X_train, Y_train,w,lamda)
            w=w+step*grad

            predictions,loss = predict(X_train,Y_train,w,lamda)
            #prediction=np.argmax(predictions,axis=1)
               
            #Y_pred=np.ones([len(prediction),2])*[0,1]
            Y_pred=np.argmax(predictions,axis=1)
            #boo=np.array(prediction)==0
            #Y_pred[boo]=[1,0]            
                             
            accuracy = (float(np.sum(np.array(Y1)==np.array(Y_pred)))/len(Y_train))

            epochs=epochs+1
      
        
        
    return w
        
def gradient(X,Y,w,lamda):
    numerator=np.array(np.exp(X*w))
    denominator=np.array([numerator.sum(axis=1)]*2).T

    Y-numerator/denominator
    grad=np.matrix(X).T*(Y-numerator/denominator)-lamda*w
    return grad
    
        
def predict(x,y,w,lamda):
    numerator=np.array(np.exp(x*w))
    denominator=np.array([numerator.sum(axis=1)]*2).T
    prediction=numerator/denominator
    loss=np.sum(np.multiply(y,prediction))
    return prediction,loss
    
def predict_dev(x,w):
    numerator=np.array(np.exp(x*w))
    denominator=np.array([numerator.sum(axis=1)]*2).T
    prediction=numerator/denominator
    Y_pred=np.argmax(prediction,axis=1)
    return Y_pred
    
    
    