1) Please run the RankSVM code, this will call the liblinearutil codes.
2) The Matrix factorization code is also included to generate the required U and V matrices.
3) LR-LETOR calls the LR code which implements logistic regression