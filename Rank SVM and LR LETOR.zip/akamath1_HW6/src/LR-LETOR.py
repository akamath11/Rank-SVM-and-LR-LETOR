import numpy as np
import pickle
import pandas as pd
import LR



U=pickle.load( open( "U_final_20.pickle", "rb" ) )
V=pickle.load( open( "V_final_20.pickle", "rb" ) )

R=U.T*V     #User Item
R=np.round(np.array(R))
X=[]
Y=[]
weights=np.matrix(np.zeros([20,2]))
index=np.array(range(R.shape[1]))

Train=pd.read_csv('train.csv',header=None)
Train=Train.drop([3],axis=1)

users=list(set(Train[1]))
count=0
for u in users:
    print(count)
    
    A=Train[Train[1]==u]
    I=A[A[2]==5][0]
    J=A[A[2]==1][0]
#    xui=np.array(np.multiply(U.T[u],V.T[I]))
#    xuj=np.array(np.multiply(U.T[u],V.T[J]))
#    
#    for x in xuj:   
#        X.extend(xui-x)
#    count=count+1
    
    for i in I:
        for j in J:
            if(i<j):
                xui=np.array(np.multiply(U.T[u],V.T[i]))
                xuj=np.array(np.multiply(U.T[u],V.T[j]))
                X.extend(xui-xuj)
                Y.append(1)
            else:
                xui=np.array(np.multiply(U.T[u],V.T[i]))
                xuj=np.array(np.multiply(U.T[u],V.T[j]))
                X.extend(xuj-xui)
                Y.append(-1)
    count=count+1


F=np.array(X)
Y=np.array(Y)

Y_train=[]
for y in Y:
    if y==1:
        Y_train.append([1,0])
    else:
        Y_train.append([0,1])

Y_train=np.array(Y_train)

weights=LR.train(F,Y_train,weights)        

Dev=pd.read_csv('dev.csv',header=None)
Dev=np.array(Dev)

U=pickle.load( open( "U_final_20.pickle", "rb" ) )
V=pickle.load( open( "V_final_20.pickle", "rb" ) )

Train=pd.read_csv('train.csv',header=None)
Train=Train.drop([3],axis=1)

f = open('SVM_dev', 'w')

count=0
for d in Dev:
    X=[]
    print(count)
    I=d[0]
    u=d[1]
    
    J=Train[Train[1]==u][0]
    xui=np.array(np.multiply(U.T[u],V.T[I]))
    xuj=np.array(np.multiply(U.T[u],V.T[J]))
    
    for x in xuj:   
        X.extend(xui-x)
        
    if(X!=[]):    
        predictions=LR.predict_dev(X,weights)
        f.write(str(sum(predictions))+'\n')
    else:
        predictions=0
        f.write(str(predictions)+'\n')
    
    
        
    
    count=count+1
    
f.close()

