import numpy as np
import pickle
import pandas as pd
from liblinearutil import *


U=pickle.load( open( "U_final.pickle", "rb" ) )
V=pickle.load( open( "V_final.pickle", "rb" ) )



X=[]
Y=[]
weights=np.matrix(np.zeros([10,2]))

Train=pd.read_csv('train.csv',header=None)
Train=Train.drop([3],axis=1)

users=list(set(Train[1]))
count=0
for u in users:
    print(count)
    
    A=Train[Train[1]==u]
    I=A[A[2]==5][0]
    J=A[A[2]==1][0]
#    xui=np.array(np.multiply(U.T[u],V.T[I]))
#    xuj=np.array(np.multiply(U.T[u],V.T[J]))
    
#    for x in xuj:   
#        X.extend(xui-x)
    for i in I:
        for j in J:
            if(i<j):
                xui=np.array(np.multiply(U.T[u],V.T[i]))
                xuj=np.array(np.multiply(U.T[u],V.T[j]))
                X.extend(xui-xuj)
                Y.append(1)
            else:
                xui=np.array(np.multiply(U.T[u],V.T[i]))
                xuj=np.array(np.multiply(U.T[u],V.T[j]))
                X.extend(xuj-xui)
                Y.append(-1)
    count=count+1
        
    
F=np.array(X)
Y=np.array(Y)

#prob=problem(Y,F)

m=train(Y,F,'-s 2')

from liblinearutil import *

Dev=pd.read_csv('test.csv',header=None)
Dev=np.array(Dev)



U=pickle.load( open( "U_final.pickle", "rb" ) )
V=pickle.load( open( "V_final.pickle", "rb" ) )

Train=pd.read_csv('train.csv',header=None)
Train=Train.drop([3],axis=1)

f = open('SVM_dev3', 'w')

count=0
for d in Dev:
    X=[]
    #print(count)
    I=d[0]
    u=d[1]
    
    J=Train[Train[1]==u][0]
        
    xui=np.array(np.multiply(U.T[u],V.T[I]))
    xuj=np.array(np.multiply(U.T[u],V.T[J]))
    
    for x in xuj:   
        X.extend(xui-x)
        
    if(X!=[]):    
        p=predict([], X, m)
        predictions=p[0]
        f.write(str(sum(predictions))+'\n')
        print(sum(predictions))
            
    else:
        predictions=0
        f.write(str(predictions)+'\n')
    
        

    
    count=count+1
    
f.close()

