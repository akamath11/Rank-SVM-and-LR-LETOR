# Please Enter the K value after running the code

import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from scipy.sparse import linalg


import time
start_time = time.time()

train=pd.read_csv('train.csv',header=None)
train=train.drop([3],axis=1)

users=train[1]
items=train[0]
values=train[2]

lambda_u=.1
lambda_v=.1
num_features=2
num_features=input('Enter K value')
alpha=0.00002
max_iter=12000
max_change=0.001

N=max(users)+1
M=max(items)+1
D=num_features
R=csr_matrix((values,(users,items)),shape=(N,M))
R=R.asfptype()
U, s, V = linalg.svds(R,k=D)
U=np.matrix(U)
V=np.matrix(V)
U=U.T
num_iter=0
g1=0
g2=0

I=R/R
where_are_NaNs = np.isnan(I)
I[where_are_NaNs] = 0
    

def grad(U,V,lambda_u,lambda_v):
    e=np.multiply(I,R-(np.transpose(U)*V))
    print(np.sum(np.ndarray.flatten(np.array(sum(e)))))
    g1=(U*e)-lambda_u*V
    g2=(V*np.transpose(e))-lambda_v*U
    return[g1,g2]

prev_e=-99999
curr_e=0    
while(num_iter<max_iter):
    [g1,g2]=grad(U,V,lambda_u,lambda_v)
 
#    if(abs(curr_e-prev_e)<max_change):
#         break
#
#    if(num_iter>500 and num_iter<800):
#        alpha=alpha/1.0005
    
    Vnew=V+alpha*g1
    Unew=U+alpha*g2
    num_iter=num_iter+1
    prev_e=curr_e
    e=np.multiply(I,R-(np.transpose(U)*V))
    curr_e=np.sum(np.ndarray.flatten(np.array(sum(e))))
    U=Unew
    V=Vnew
    
query=pd.read_csv('dev.csv',header=None)

R1=U.T*V

#For the rows/user_ids in the query find the similarity row
fout=open('Matrix_factorization_k10.txt','w')

for i in range(len(query)):
    print(i)
    user=query.loc[i][1]
    movie=query.loc[i][0]
    score=R1[user,movie]
    fout.write(str(score))
    fout.write('\n')
    
fout.close()

import pickle
pickle.dump( U, open( "U_final_100.pickle", "wb" ) )
pickle.dump( V, open( "V_final_100.pickle", "wb" ) )


    
print("--- %s seconds ---" % (time.time() - start_time))    

